package com.ibm.training.Wallet_Spring;


public class AppTest 

{

}
