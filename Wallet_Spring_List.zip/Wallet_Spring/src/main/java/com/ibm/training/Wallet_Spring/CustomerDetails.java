package com.ibm.training.Wallet_Spring;

public class CustomerDetails {
	String name;
   int accountNo;
   int balance;
   
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAccountNo() {
	return accountNo;
}
public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}


}