package com.ibm.training.Wallet_Spring;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("walletBean.xml");

    	TransactionDetails trans = context.getBean("service" , TransactionDetails.class);
    	   	

    	Scanner sc = new Scanner(System.in);		
 		  boolean quit = false;

 	        do 

 	        {       	
 	        	
 	     System.out.print("Please enter your choice: " + "\nAdd Account" + "\nShow Accounts" + "\nWithdraw" + "\nDeposite" +"\nAccount details"+ "\nExit\n");
 	     String menu = sc.nextLine();
 	     menu = menu.toLowerCase();
 	     
 	     switch (menu)
 	     {
 	     case "add account": 
 	    	 
 		 System.out.println("Enter User Name :"); 
 		 String name = sc.nextLine();
 		 
 		  
 		  System.out.println("Enter Account Number :"); 
 		  int accno = sc.nextInt();
 		  sc.nextLine(); 
 		
 		  
           System.out.println("Enter Initial Balance :"); 
           int bal = sc.nextInt();
 		  trans.insertAccount(name,accno,bal);
 		  break;
 	     
 		  
			
			 case "show accounts":
			 
		List<CustomerDetails> detail= trans.showDetails();
    	
    	for(CustomerDetails c: detail)
    	{
    		System.out.println("Name : "+c.getName());
    		System.out.println("AccountNo : "+c.getAccountNo());
    		System.out.println("Balance :"+c.getBalance());
    	}
			  break;
			  
			  case "withdraw":
			  
			  System.out.println("Enter Account Number from which Amount to be withdraw :" ); 
			  int with = sc.nextInt(); 
			  sc.nextLine();  
			  trans.withdraw(with);
			  break;
			  
			  case "deposite":
				  
				  System.out.println("Enter Account Number to which Amount to be deposite :" ); 
				  int dep = sc.nextInt(); 
				  sc.nextLine();  
				  trans.deposite(dep);
				  break;
			 
				  
				 case "account details":
					 
					 System.out.println("Enter Account Number you want to see details:" ); 
					  int ano = sc.nextInt(); 
					  sc.nextLine();  
					 CustomerDetails cd3 = trans.accdetail(ano);
					  System.out.println("Name : "+cd3.getName());
			    		System.out.println("AccountNo : "+cd3.getAccountNo());
			    		System.out.println("Balance :"+cd3.getBalance());
			           
					
				     break;
 		
 	    case "exit": 
             System.out.println("Thank You !");
         quit = true; 
     }
 	        }
     while (!quit);
 	     
 }
    }

