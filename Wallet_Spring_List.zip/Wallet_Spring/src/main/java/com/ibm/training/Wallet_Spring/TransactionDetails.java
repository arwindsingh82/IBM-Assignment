package com.ibm.training.Wallet_Spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;





public class TransactionDetails {

	
  Dao dao;

	public Dao getDao() {
		return dao;
	}

	public void setDao(Dao dao) {
		this.dao = dao;
	}

	

	public List<CustomerDetails> showDetails() {
		return dao.getCustomerDetails();
	}

	public List<CustomerDetails> insertAccount(String name, int accno, int bal) {
		return dao.insertAccount(name, accno,bal);
		
	}

	public List<CustomerDetails> withdraw(int with) {
		return dao.withdraw(with);
		
	}

	public List<CustomerDetails> deposite(int dep) {
		return dao.deposite(dep);
	
		
	}

	public CustomerDetails accdetail(int ano) {
		return dao.accdetail(ano);
		
		
	}


	
	
} 
