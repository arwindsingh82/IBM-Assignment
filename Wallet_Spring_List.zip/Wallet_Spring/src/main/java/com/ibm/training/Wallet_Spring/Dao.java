package com.ibm.training.Wallet_Spring;

import java.util.List;
import java.util.Scanner;

public class Dao 
{
   CustomerDetails cd = new CustomerDetails();
   Scanner sc = new Scanner(System.in);
   
	List<CustomerDetails> details;
	

	public List<CustomerDetails> getDetails() {
		return details;
	}

	public void setDetails(List<CustomerDetails> details) {
		this.details = details;
	}


	public List<CustomerDetails> getCustomerDetails() {
		
		return getDetails();
	}
	

	public List<CustomerDetails> insertAccount(String name, int accno, int bal) {
		cd.setAccountNo(accno);
		cd.setBalance(bal);
		cd.setName(name);
		
		details.add(cd);
		return details;
	}

	public List<CustomerDetails> withdraw(int with) {
		int amount = 0;
	    int fbal = 0;
	    CustomerDetails cd1 =null;
		
		 for (CustomerDetails cd: details) 
		 {
			  int count =0;
			 
		        if (cd.getAccountNo()== with) 
		        {
		           amount= cd.getBalance();
		           cd1 =cd;
		        }else {
		        	  count = 1;
		        }
		        	  if(count==0) {
		        	System.out.println("Account Number Matched");
		        	  }		       
		 }
		 
		 System.out.println("Enter Amount to be withdraw :" ); 
		  int amt = sc.nextInt(); 
		  sc.nextLine();
		  
		  fbal = amount - amt;
		  
		  cd1.setBalance(fbal); 
		 return details;
		
		
	}

	public List<CustomerDetails> deposite(int dep) {
		int amount = 0;
	    int fbal = 0;
	    CustomerDetails cd2 =null;
		
		 for (CustomerDetails cd: details) 
		 {
			  int count =0;
			 
		        if (cd.getAccountNo()== dep) 
		        {
		           amount= cd.getBalance();
		           cd2 = cd; // to hold the account we found
		        }else {
		        	  count = 1;
		        }
		        	  if(count==0) {
		        	System.out.println("Account Number Matched");
		        	  }		       
		 }
		 
		 System.out.println("Enter Amount to be deposite :" ); 
		  int amt = sc.nextInt(); 
		  sc.nextLine();
		  
		  fbal = amount + amt;
		  
		  cd2.setBalance(fbal); 
		 return details;
		
	}

	public CustomerDetails accdetail(int ano) {
		CustomerDetails cd3 =null;
		for (CustomerDetails cd: details) 
		 {
			  int count =0;
			 
		        if (cd.getAccountNo()== ano) 
		        {
		          int amount= cd.getBalance();
		          String name = cd.getName();
		          int Account = cd.getAccountNo();
		           cd3 = cd; // to hold the account we found
		           
		        }else {
		        	  count = 1;
		        }
		        	  if(count==0) {
		        	System.out.println("Account Number Matched");
		        	  }		       
		 }
		
		return cd3;
	}
	
}
