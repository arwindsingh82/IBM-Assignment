package com.ibm.training.user;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate; //registered beans
	
	public String getUser(int id) {
		
		String qry = "select userName from userdetails where userId = ?";
		
		return jdbcTemplate.queryForObject(qry, new Object[] {id}, String.class);
		
	}

	//All detail of user by mapping
	 User getUserDetail(int id) {
		 String qry = "select * from userdetails where userId = ?";
		return jdbcTemplate.queryForObject(qry, new Object[] {id}, new UserMapper());
	}
	 



	//this USerMapper will map each row of table using User class and execute till it map all row according to query (* than for all row)
		class UserMapper implements RowMapper<User> {
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			// object for User class to map
				User user = new User();
		   // set userName for mapping and get all name		
				user.setUserName(rs.getString("userName"));
				user.setUserId(rs.getInt("userId"));
				user.setUserAddress(rs.getString("userAddress"));
				user.setUserGender(rs.getString("userGender"));
				return user;
			
			}
		}


// update user by id
		public void updateUser(User user ,int id) {
			String qry = "update userdetails set userName='SHIVAM SHUKLA' where userId =?";
			jdbcTemplate.update(qry, new Object[] {id});
			
		}

		
		
		// delete user
		public void deleteUser(int id) {
			String qry = "DELETE FROM userdetails WHERE userId =?";
			jdbcTemplate.update(qry, new Object[] {id});
			
		}

		public void addUser(User user) {

      String qry = "insert into userDetails values (?,?,?,?)";
      jdbcTemplate.update(qry, new Object[] {
    		  user.getUserId(),
				user.getUserName(),
				user.getUserAddress(),
				user.getUserGender()
      });
		}
				 
	 

}
