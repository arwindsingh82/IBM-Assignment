package com.ibm.training.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


//#1
@RestController
public class MyController {
	
	@Autowired
	UserService service;

	//#2
	@RequestMapping("/user/{id}")
	String getUser(@PathVariable int id) {
		return service.getUser(id);
	}
	
	
	// fetch all detail of one user from table
	@RequestMapping("/users/{id}")
	User getUserDetail(@PathVariable int id) {
		return service.getUserDetail(id);
	}
	
	
	//update detail
	@RequestMapping(method = RequestMethod.PUT , value = "/update/{id}")
	void updateUser(@RequestBody User user ,@PathVariable int id) {
		service.updateUser(user, id);
	}
	
	
	//Delete detail
	@RequestMapping(method = RequestMethod.DELETE , value ="/delete/{id}")
	void deleteUser(@PathVariable int id) {
	service.deleteUser(id);
}
	
// Add new user
	@RequestMapping(method = RequestMethod.POST , value ="/add")
	void addUser() {
		service.addUser(new User(100,"Sss","Noida","M"));
	}
	
	
	
}
