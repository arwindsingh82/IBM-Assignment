package com.ibm.training.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//#4
@Service
public class UserService {
    
	@Autowired
	UserDao dao;
	
  
	// userName from table
  String getUser(int id) {
	return dao.getUser(id);
}


  // All details of one user
  User getUserDetail(int id) {	
	return dao.getUserDetail(id);
}

//update user
public void updateUser(User user, int id) {
	dao.updateUser(user , id);
	
}

// delete
public void deleteUser(int id) {
	dao.deleteUser(id);
}


public void addUser(User user) {
	dao.addUser(user);
	
}
	
	
}
