package com.ibm.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootjdbcTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootjdbcTemplateApplication.class, args);
		System.out.println("working");
	}

}
