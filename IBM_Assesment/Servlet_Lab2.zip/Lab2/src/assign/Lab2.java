package assign;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Lab2")
public class Lab2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
	
		String userName = request.getParameter("userName");
		String pass = request.getParameter("pass");
		
		request.setAttribute("userName", userName);
		request.setAttribute("pass", pass);
	
         

        	 if(request.getAttribute("userName").equals("Arwind") && request.getAttribute("pass").equals("1234"))
        	 {
        		 response.getWriter().println("Sucess");
        		
        			//response.sendRedirect("index.html");
        			
        		}
        		else
        		{
        			response.getWriter().print("Failure");
        			//response.sendRedirect("index.html");
        			
        			
    			
        			
        		}
        	 }
		
		


}
