package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import account.AccountDetails;

import ui.Ui;

public class DatabaseConnection {
	
        Connection dbCon;        
        PreparedStatement theStatement1;
        AccountDetails ad = new AccountDetails();
        Ui input = new Ui();
        
        Scanner scan = new Scanner(System.in);
      
    	public void Connectionlink()
    	{
    		
    	}
   	
 
	
	  public void openAccount(AccountDetails ad) {
	 	  String Qry = "insert into accountholderdetails values(?,?,?)";
	  
	  try { Class.forName("com.mysql.cj.jdbc.Driver");
	  
	  this.dbCon=DriverManager.getConnection(
	  "jdbc:mysql://localhost:3306/ibm_fsd_training?serverTimezone=UTC", "root",
	  ""); this.theStatement1 = dbCon.prepareStatement(Qry);
	  
	  this.theStatement1.setString(1, ad.getUserName());
	  this.theStatement1.setInt(2, ad.getAccNo()); 
	  this.theStatement1.setInt(3, ad.getBalance());
	  
	  
	  if(this.theStatement1.executeUpdate() > 0) {
	  System.out.println("User details updated"); }
	  
	  }catch(ClassNotFoundException | SQLException e) {
	  System.out.println("Issuewhile updating: " + e); }
	  
	  }
	 
    	
    	
    	public void displayBalance(AccountDetails ad) {
  		    
 		     String Qry1 = "select * from accountholderdetails where Acc_no = ?";
 		
 		     
   		try {
   			Class.forName("com.mysql.cj.jdbc.Driver");
   			
   			this.dbCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm_fsd_training?serverTimezone=UTC", "root", "");
   		    this.theStatement1 = dbCon.prepareStatement(Qry1);
   	
   		this.theStatement1.setInt(1, ad.getAccNo());
      		
   		ResultSet theResultSet = this.theStatement1.executeQuery();
   		
   		while(theResultSet.next()) {
			System.out.println("Name : " + theResultSet.getString("Name"));
			System.out.println("Account Number : " + theResultSet.getInt("Acc_no"));
			System.out.println("Balance : " + theResultSet.getInt("Balance"));
		}

     		
   		}catch(ClassNotFoundException | SQLException e) {
   			System.out.println("Issuewhile updating: " + e);
   		}
   		
   	}
    	
    
    	public void deposite(AccountDetails ad) {
    		  int amount = 0;
    		  int depbal;
		     String Qry1 = "select Balance from accountholderdetails where Acc_no = ?";
		     String Qry = "update accountholderdetails set Balance = ? where Acc_no = ?";
		  
		     
  		try {
  			Class.forName("com.mysql.cj.jdbc.Driver");
  			
  			this.dbCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm_fsd_training?serverTimezone=UTC", "root", "");
  		    this.theStatement1 = dbCon.prepareStatement(Qry1);
  	
  		this.theStatement1.setInt(1, ad.getAccNo());
     		
  		ResultSet theResultSet = this.theStatement1.executeQuery();
  		
  		
  		
             while (theResultSet.next()) 
             {
                 System.out.printf("Current Balance  : "+"%,d"+"\n",theResultSet.getInt("Balance"));

                 amount = theResultSet.getInt("Balance");
              

             }
             System.out.println("");
             System.out.println("Enter deposit amount : ");
            depbal = scan.nextInt();

             amount = amount + depbal;
             System.out.printf("Available balance : "+"%,d"+"\n" , amount);
             
         
           
		     this.theStatement1 = dbCon.prepareStatement(Qry);
		     this.theStatement1.setInt(2, ad.getAccNo());		   
		     this.theStatement1.setInt(1, amount);
		     
	
		     
			if(this.theStatement1.executeUpdate() > 0) {
				System.out.println("User details updated...");
			}
    		
  		}catch(ClassNotFoundException | SQLException e) {
  			System.out.println("Issuewhile updating: " + e);
  		}
    	}
    	
    	
    	public void transfer(AccountDetails ad) {
    		int amount1 = 0; 
   		 int amount2 = 0;
   		  int transbal;
		     String Qry1 = "select Balance from accountholderdetails where Acc_no = ?";
		     String Qry2 = "update accountholderdetails set Balance = ? where Acc_no = ?";
		     
		     String Qry3 = "select Balance from accountholderdetails where Acc_no = ?";		 
		     String Qry4 = "update accountholderdetails set Balance = Balance + ? where Acc_no = ?";
		     
 		try {
 			Class.forName("com.mysql.cj.jdbc.Driver");
 			
 			this.dbCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm_fsd_training?serverTimezone=UTC", "root", "");
 		    this.theStatement1 = dbCon.prepareStatement(Qry1);
 	
 		this.theStatement1.setInt(1, ad.getAccNo());
    		
 		ResultSet theResultSet = this.theStatement1.executeQuery();
 		
 		
 		
            while (theResultSet.next()) 
            {
                System.out.printf("Current Balance  : "+"%,d"+"\n",theResultSet.getInt("Balance"));

                amount1 = theResultSet.getInt("Balance");
             

            }
            System.out.println("");
            System.out.println("Enter tansfer amount : ");
           transbal = scan.nextInt();

            amount1 = amount1 - transbal;
            System.out.printf("Available balance : "+"%,d"+"\n" , amount1);
            
            this.theStatement1 = dbCon.prepareStatement(Qry2);
            this.theStatement1.setInt(1, amount1);
            this.theStatement1.setInt(2, ad.getAccNo());
		    
		     theStatement1.executeUpdate();
            
        
			
			  System.out.println(""); 
			  System.out.println("Enter Account Number to which amout transfer : ");
			  int an = scan.nextInt();
			  scan.nextLine(); 
			  ad.setAccNo(an);
			 
			  
			  
			  this.theStatement1 = dbCon.prepareStatement(Qry3);			 	
		 		this.theStatement1.setInt(1, ad.getAccNo());		    		
		 		ResultSet theResultSet1 = this.theStatement1.executeQuery();
		 		
		 		 while (theResultSet.next()) 
		            {
		                System.out.printf("Current Balance  : "+"%,d"+"\n",theResultSet1.getInt("Balance"));
		                amount2 = theResultSet1.getInt("Balance");             

		            }
		 		

            amount2 = amount2 + transbal;
            System.out.printf("Available balance : "+"%,d"+"\n" , amount2);
            
            
          
		     this.theStatement1 = dbCon.prepareStatement(Qry4);
		     this.theStatement1.setInt(1, amount2);
		     this.theStatement1.setInt(2, an);		   
		   
		     

		     
			if(this.theStatement1.executeUpdate() > 0) {
				System.out.println("User details updated...");
			}
   		
 		}catch(ClassNotFoundException | SQLException e) {
 			System.out.println("Issuewhile updating: " + e);
 		}
   	}
    	
   
    	
    	public void withdraw(AccountDetails ad) {
  		    
   		 int amount = 0;
  		  int withbal;
		     String Qry1 = "select Balance from accountholderdetails where Acc_no = ?";
		     String Qry = "update accountholderdetails set Balance = ? where Acc_no = ?";
		     
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			this.dbCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm_fsd_training?serverTimezone=UTC", "root", "");
		    this.theStatement1 = dbCon.prepareStatement(Qry1);
	
		this.theStatement1.setInt(1, ad.getAccNo());
   		
		ResultSet theResultSet = this.theStatement1.executeQuery();
		
		
		
           while (theResultSet.next()) 
           {
               System.out.printf("Current Balance  : "+"%,d"+"\n",theResultSet.getInt("Balance"));

               amount = theResultSet.getInt("Balance");
            

           }
           System.out.println("");
           System.out.println("Enter withdraw amount : ");
          withbal = scan.nextInt();

           amount = amount - withbal;
           System.out.printf("Available balance : "+"%,d"+"\n" , amount);
           
       
         
		     this.theStatement1 = dbCon.prepareStatement(Qry);
		     this.theStatement1.setInt(1, amount);
		     this.theStatement1.setInt(2, ad.getAccNo());		   
		   
		     
		     
			if(this.theStatement1.executeUpdate() > 0) {
				System.out.println("User details updated...");
			}
  		
		}catch(ClassNotFoundException | SQLException e) {
			System.out.println("Issuewhile updating: " + e);
		}
  	}
    	
    	
}
