package ui;

import java.util.Scanner;

import account.AccountDetails;
import service.Service;

public class Ui {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	   AccountDetails ad = new AccountDetails();
		Service s = new Service();
		
		  boolean quit = false;

	        do 

	        {       	
	        	
	     System.out.print("Please enter your choice: " + "\nCreate Account" + "\nDisplay Balance" + "\nWithdraw" + "\nDeposite" +"\nTransfer"+ "\nExit\n");
	     String menu = sc.nextLine();
	     menu = menu.toLowerCase();
	     
	     switch (menu)
	     {
	     case "create account": 
	    	 
		 System.out.println("Enter User Name :"); 
		 String name = sc.nextLine();
		  ad.setUserName(name);
		  
		  System.out.println("Enter Account Number :"); 
		  int accno = sc.nextInt();
		  sc.nextLine(); 
		  ad.setAccNo(accno);
		  
          System.out.println("Enter Initial Balance :"); 
          int bal = sc.nextInt();
		  ad.setBalance(bal); 
		  s.openAccount(ad);
		  break;
	     
		  
	    case "display balance":
	    	
		System.out.println("Enter Account Number to Display Balance :");
		int accnum = sc.nextInt();
		sc.nextLine();
		ad.setAccNo(accnum);
		s.displayBalance(ad);
		break;
		
	    case "withdraw":
	    	
		  System.out.println("Enter Account Number from which Amount to be withdraw :"); 
		  int acn = sc.nextInt(); 
		  sc.nextLine(); 
		  ad.setAccNo(acn);
		  s.withdraw(ad);
		 break; 
		  
		  
	    case "deposite":
	    	
		  System.out.println("Enter Account Number from which Amount to be deposite :"); 
		  int accn = sc.nextInt();
		  sc.nextLine(); 
		  ad.setAccNo(accn);
		  s.deposite(ad);
		  break;
		  
		  
	    case "transfer":
	    	
			  System.out.println("Enter Account Number from which Amount to be transfer :"); 
			  int accountn = sc.nextInt();
			  sc.nextLine(); 
			  ad.setAccNo(accountn);
			  s.transfer(ad);
			  break;
		  
		
	    case "exit": 
            System.out.println("Thank You !");
        quit = true; 
    }
	        }
    while (!quit);
	     
}
	  }
