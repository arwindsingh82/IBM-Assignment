package service;

import account.AccountDetails;
import database.DatabaseConnection;


public class Service {

	AccountDetails ad = new AccountDetails();
	DatabaseConnection db = new DatabaseConnection();
	
	
	  public void openAccount(AccountDetails ad) {	  
	  db.openAccount(ad); 
	  }
	 
	
	public void displayBalance(AccountDetails ad) {		
		db.displayBalance(ad);
	}
	
	public void deposite(AccountDetails ad) {
		db.deposite(ad);		
	}
	
	public void withdraw(AccountDetails ad) {
		db.withdraw(ad);		
	}
	
	public void transfer(AccountDetails ad) {
		db.transfer(ad);		
	}
}
