package account;

public class AccountDetails {

private String userName;
private int accNo;
private int deposite;
private int withdraw;
private int balance;
private int transfer;

public AccountDetails(String userName, int accNo, int deposite, int withdraw, int balance, int tranfer) {
	
	this.userName = userName;
	this.accNo = accNo;
	this.deposite = deposite;
	this.withdraw = withdraw;
	this.balance = balance;
	this.transfer = transfer;
	}

public AccountDetails(){
	
}


public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public int getAccNo() {
	return accNo;
}

public void setAccNo(int accNo) {
	this.accNo = accNo;
}

public int getDeposite() {
	return deposite;
}

public void setDeposite(int deposite) {
	this.deposite = deposite;
}

public int getWithdraw() {
	return withdraw;
}

public void setWithdraw(int withdraw) {
	this.withdraw = withdraw;
}

public int getBalance() {
	return balance;
}

public void setBalance(int balance) {
	this.balance = balance;
}

@Override

public String toString()
{
	 return "Account Details:\n Account Number : "  +getAccNo()+"\tCustomer Name : "+getUserName()+"\tDeposite amount : "+getDeposite()+"\t Withdraw Amount : "+getWithdraw()+"\t Final Balance : "+getBalance();
}




}
