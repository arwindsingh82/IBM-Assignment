package com.ibm.training.Spring_Jdbc;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class Param {

	DataSource ds;
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	public DataSource getDs() {
		return ds;
	}
	public void setDs(DataSource ds) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(ds);
		//this.ds = ds;
	}
	
	
	
	
	
	
}
