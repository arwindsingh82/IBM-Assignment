package com.ibm.training.Spring_Jdbc;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	//#2
       ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beanContent.xml");
       
       //#3
       JdbcDao dao = (JdbcDao) context.getBean(JdbcDao.class);
       
       System.out.println(dao.getUserCount());
       System.out.println(dao.getUserName(2001));
       
       //for one user all detail
       User user = dao.getUserDetail(2001);
       System.out.println("UserId :" +user.getUserId()+ "\tName : " + user.getUserName()+  "\tAddress :"+ user.getUserAddress()+ "\tGender :" +user.getUserGender());
       
       
      //for all users
       for(User user1 : dao.getAllUser()) {
    	   System.out.println("UserId :" +user1.getUserId()+ "\tName : " + user1.getUserName()+  "\tAddress :"+ user1.getUserAddress()+ "\tGender :" +user1.getUserGender());
       }
       
       
       //Add user
       dao.addNewUser(new User("Rahul", "Punjab", "Male", 5001));
       
    }
}


