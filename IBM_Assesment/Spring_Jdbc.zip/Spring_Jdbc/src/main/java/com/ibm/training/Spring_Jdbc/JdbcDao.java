package com.ibm.training.Spring_Jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository; 

@Repository
public class JdbcDao {

	// #4
	//@Autowired
	DataSource ds;

	// this move in setter and ds pass and Autowired done below. 
//JdbcTemplate jdbcTemplate = new JdbcTemplate();
	
	// #5
	JdbcTemplate jdbcTemplate;
	
	
	public DataSource getDs() {
		return ds;
	}
   
	@Autowired
	public void setDs(DataSource ds) {
		
		this.jdbcTemplate=new JdbcTemplate(ds);	
	}
	
	    
	// count total number of user
	int getUserCount() {
		String qry = "select count(userName) from userDetails";
		return jdbcTemplate.queryForObject(qry, Integer.class);
	}
	
	
	 //fetch username from table using id
	
	String getUserName(int userId) {
		String qry = "select userName from userDetails where userId = ?";
		// new Object[] {} is a anonymous array object
		return jdbcTemplate.queryForObject(qry, new Object[] {userId}, String.class);	
		
	}
	
	//fetch all detail of one user by mapping, list not required bcz only one data
	User getUserDetail(int userId) {
		String qry = "select * from userDetails where userId = ?";
		return jdbcTemplate.queryForObject(qry, new Object[] {userId}, new UserMapper());
	}
	
	
	
	
	
	
	//fetch all username from table
	//simple query as above will not return data. Mapper class needed, return type list<object>
	
	List<User> getAllUser() {
	 String qry = "select * from userDetails";
			 return jdbcTemplate.query(qry, new UserMapper());
	}

	
	//this USerMapper will map each row of table using User class and execute till it map all row according to query (* than for all row)
	class UserMapper implements RowMapper<User> {

		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		// object for User class to map
			User user = new User();
	   // set userName for mapping and get all name		
			user.setUserName(rs.getString("userName"));
			user.setUserId(rs.getInt("userId"));
			user.setUserAddress(rs.getString("userAddress"));
			user.setUserGender(rs.getString("userGender"));
			return user;
		
		}		
	}
	
	//Add user detail to table, constructor set automatically. if setter use than first set and than get.
	void addNewUser(User user) {
		String qry = "insert into userDetails values (?, ?, ?, ?)";
		jdbcTemplate.update(qry, new Object[] {
				user.getUserId(),
				user.getUserName(),
				user.getUserAddress(),
				user.getUserGender()
		});
	}
	
	
	
	
	
	} 

	
  
