package com.ibm.training.Spring_Jdbc;

public class User {
String userName, userAddress, userGender;
Integer userId;

public User(String userName, String userAddress, String userGender, Integer userId) {
	this.userName = userName;
	this.userAddress = userAddress;
	this.userGender = userGender;
	this.userId = userId;
}
public User() {
	// TODO Auto-generated constructor stub
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserAddress() {
	return userAddress;
}
public void setUserAddress(String userAddress) {
	this.userAddress = userAddress;
}
public String getUserGender() {
	return userGender;
}
public void setUserGender(String usergender) {
	this.userGender = usergender;
}
public Integer getUserId() {
	return userId;
}
public void setUserId(Integer userId) {
	this.userId = userId;
}



}
